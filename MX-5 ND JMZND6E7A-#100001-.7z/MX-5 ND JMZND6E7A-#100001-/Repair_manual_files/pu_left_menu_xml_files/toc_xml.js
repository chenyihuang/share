var framesTop = parent.parent;

var LoadDiv = '<DIV ONCLICK="loadFrame(true);" CLASS="clsLoadMsg">';
L_LoadingMsg_HTMLText = LoadDiv + L_LoadingMsg_HTMLText + "</LI>";

function caps(){
    var UA = navigator.userAgent;
    if(UA.indexOf("MSIE") != -1){
        this.ie = true;
        var v = UA.charAt(UA.indexOf("MSIE") + 5);
        if(v == 2 ) this.ie2 = true;
        else if(v == 3 ) this.ie3 = true;
        else if(v == 4 ) this.ie4 = true;
        else if(v == 5 ) this.ie5 = true;
        if(this.ie4 || this.ie5) this.UL = true;
    }else if(UA.indexOf("Mozilla") != -1 && UA.indexOf("compatible") == -1){
        this.nav = true;
        var v = UA.charAt(UA.indexOf("Mozilla") + 8);
        if(v == 2 ) this.nav2 = true;
        else if(v == 3 ) this.nav3 = true;
        else if(v == 4 ) this.nav4 = true;
    }
    if(UA.indexOf("Windows 95") != -1 || UA.indexOf("Win95") != -1 || UA.indexOf("Win98") != -1 || UA.indexOf("Windows 98") != -1 || UA.indexOf("Windows NT") != -1) this.win32 = true;
    else if(UA.indexOf("Windows 3.1") != -1 || UA.indexOf("Win16") != -1) this.win16 = true;
    else if(UA.indexOf("Mac") != -1) this.anymac = true;
    else if(UA.indexOf("SunOS") != -1 || UA.indexOf("HP-UX") != -1 || UA.indexOf("X11") != -1) this.unix = true;
    else if(UA.indexOf("Windows CE") != -1) this.wince = true;
}

var bc = new caps();

var initilaflg = 0;

var eCurrentObj = null;

var L_LoadingMsg_HTMLText = "Now Reading ";

////////////////////////////////////////////
// Not sure why this is here, it puts a scrollbar up when none is needed
// if("object" == typeof(parent.document.all.fraPaneToc)) parent.document.all.fraPaneToc.scrolling = "yes";
////////////////////////////////////////////

var eSynchedNode = null;
var eCurrentUL = null;
var eCurrentLI = null;
var bLoading = false;

function loadFrame( bStopLoad )
{
	// �c���[���J���ꍇ
	if( "object" == typeof( eCurrentUL ) && eCurrentUL && !bStopLoad )
	{
		//UL�^�O��innerHTML�ɑ΂��āAXML���璊�o����HTML��}������
		eCurrentUL.innerHTML = '';
		eCurrentUL.innerHTML = hiddenframe.chunk.innerHTML;	

		eCurrentUL = null;
		bLoading = false;
		
		// �A���m�[�h�I�[�v������
		Toc_open();
	}
	// �c���[�����ꍇ
    else if( "object" == typeof( eCurrentUL ) && eCurrentUL )
    {
		eCurrentUL.parentElement.children[1].className = "";
		eCurrentUL.parentElement.children[0].src = "/esicont/esi_common/images/plus2.png";
		eCurrentUL.parentElement.className = "kid";
		eCurrentUL.className = "clsHidden";
		eCurrentUL.innerHTML="";
		eCurrentUL = null;
		bLoading = false;
    }
    else
    {
		bLoading = false;
    }
    return;
}

function GetNextUL(eSrc)
{
	
    var eRef = eSrc;
    for(var i = 0; i < eRef.children.length; i++) if("UL" == eRef.children[i].tagName) return eRef.children[i];
    return false;
}

function MarkSync(eSrc)
{
    if("object" == typeof(aNodeTree)) aNodeTree = null;
    if("LI" == eSrc.tagName.toUpperCase() && eSrc.children[1] && eSynchedNode != eSrc )
    {
		UnmarkSync();
        eSrc.children[1].style.fontWeight = "bold";
        eSynchedNode = eSrc;
    }
}

function UnmarkSync()
{
    if("object" == typeof(eSynchedNode) && eSynchedNode )
    {
        eSynchedNode.children[1].style.fontWeight = "normal";
        eSynchedNode = null;
    }
}

function MarkActive(eLI)
{
    if( "object" == typeof( eLI ) && eLI && "LI" == eLI.tagName.toUpperCase() && eLI.children[1])
    {
		window.eCurrentLI = eLI;
		MarkInActive();
        if(window.eCurrentLI.children[1].target == "main" && initilaflg == 1)
        {
	 		window.eCurrentLI.children[1].className = "clsCurrentLI";
			eCurrentObj = window.eCurrentLI;
		}
		initialflag = 1;
    }
}

function MarkInActive()
{
 	if( "object" == typeof( eCurrentLI ) && eCurrentLI &&  "object" == typeof( eCurrentObj ) && eCurrentObj )
    {
		if (window.eCurrentLI.children[1].target == "main")
		{
			eCurrentObj.children[1].className = "";
			eCurrentObj = null;
		}
    }
}

function Navigate_URL( eSrc )
{
    var eLink = eSrc.parentElement.children[1];
	    urlIdx = eLink.href.indexOf( "URL=" );
    if("object" == typeof(framesTop.main) && eLink && "A" == eLink.tagName && urlIdx != -1 )
    {
        if(eLink.target=="main"||eLink.target=="_top")
        {
            framesTop.main.location.href = eSrc.parentElement.children[1].href.substring( urlIdx + 4 );
        }else
        {
            window.open(eSrc.parentElement.children[1].href,eLink.target);
        }
        MarkSync(eSrc.parentElement);
    }else if("object" == typeof(framesTop.main) && eLink && "A" == eLink.tagName  && eLink.href.indexOf( "tocPath=" ) == -1)
    {
        if(eLink.target=="main")
        {
			if(parent.frames("param").document.frm1.srvccd.value == "")
			{
				parent.frames("param").document.frm1.srvccd.value =  parent.frames("srvc_menu").document.frm1.srvckbn.options[parent.frames("srvc_menu").document.frm1.srvckbn.selectedIndex].value;
			}
			parent.frames("param").document.frm1.siecd.value = eSrc.parentElement.children[1].name;
			parent.frames("param").document.frm1.submit();
        }
        
        else if( eLink.target=="_top" )
        {
            top.location = eLink.href;
            return;
        }
	        MarkSync(eSrc.parentElement);
    }
    else if( eSynchdNode != eSrc.parentElement && ( urlIdx != -1 || ( eLink.href.indexOf( "javascript:" ) == -1 && eLink.href.indexOf( "tocPath=" ) == -1 ) ) )
    {
        MarkSync( eSrc.parentElement );
    }
}

function Image_Click( eSrc , bLeaveOpen )
{
	var eLink = eSrc.parentElement.children[1];
	initilaflg = 1;
	if("noHand" != eSrc.className)
	{
		eLI = eSrc.parentElement;
		MarkActive(eLI);
		var eUL = GetNextUL(eLI);
		if(eUL && "kidShown" == eLI.className)
        {
            // hide on-page kids
            if( !bLeaveOpen )
            {
                eLI.className = "kid";
                eUL.className = "clsHidden";
                eSrc.src = "/esicont/esi_common/images/plus2.png";
            }
        }
        else if(eUL && eUL.all.length && "kid" == eLI.className)
        {
          // show on-page kids
            eLI.className = "kidShown";
            eUL.className = "clsShown";
            eSrc.src = "/esicont/esi_common/images/minus2.png";
        }
        else if("kid" == eLI.className)
        {
           // load off-page kids
            if( !bLoading )
            {
                bLoading = true;
                eLI.className = "kidShown";
                eUL.className = "clsShown";
                window.eCurrentUL = eUL;
                eSrc.src = "/esicont/esi_common/images/minus2.png";
                eUL.innerHTML = L_LoadingMsg_HTMLText;
				var strLoc = eLink.href;
				document.frames["hiddenframe"].location.replace(strLoc);
            }
        }
    }
}

function Toc_click()
{
	var eSrc = parentElementRepeatLI(window.event.srcElement);
	if (eSrc == null){
		return;
	}
	event.returnValue = false;
    if("A" == eSrc.tagName.toUpperCase() && "LI" == eSrc.parentElement.tagName)
    {
        var eImg = eSrc.parentElement.children[0];
        if(eImg) eImg.click();
    }
    else if("SPAN" == eSrc.tagName && "LI" == eSrc.parentElement.tagName)
    {
        var eImg = eSrc.parentElement.children[0];
        if(eImg) eImg.click();
    }
    else if("IMG" == eSrc.tagName)
    {
        Image_Click( eSrc , false );
        Navigate_URL( eSrc );
    }
    return event.returnValue;
}

function Toc_click_src(eSrc)
{
	var eSrc = eSrc;
    if("A" == eSrc.tagName.toUpperCase() && "LI" == eSrc.parentElement.tagName)
    {
        var eImg = eSrc.parentElement.children[0];
        if(eImg) eImg.click();
    }
    else if("SPAN" == eSrc.tagName && "LI" == eSrc.parentElement.tagName)
    {
        var eImg = eSrc.parentElement.children[0];
        if(eImg) eImg.click();
    }
    else if("IMG" == eSrc.tagName)
    {
        Image_Click( eSrc , false );
        Navigate_URL( eSrc );
    }
}

function Toc_dblclick()
{
	return;
}

function mouse_over()
{
    var eSrc = window.event.srcElement;
}

/*
function Toc_open()
{
// �w�肵���I�u�W�F�N�g��id="openlist"�̒l�����ɃI�[�v������ 
// 
// eSrc �ɂ�getElementById�Ŏ擾�������I�u�W�F�N�gID���g�p����
	var layOpenlist = document.getElementById("openlist");
	if(layOpenlist.value != "")
	{
		var aryOpenlist = layOpenlist.value.split(",");
		alert(aryOpenlist.shift()); 
	}
	eSrc = document.getElementById(eSrc_id);
	//alert(eSrc_id);
	 	event.returnValue = false;
	     var eImg = eSrc.parentElement.children[0];
	     if(eImg) eImg.click();
}
*/

function Toc_open()
{
	var layOpenlist = document.getElementById("openlist");
	// ����TOC�����݂���ΘA�����ĊJ��
	if("object" == typeof(layOpenlist) && layOpenlist.value != "")
	{
		var aryOpenlist = layOpenlist.value.split(",");
		var eSrc_id = aryOpenlist.shift();
		
		// ������TOC�����݂���Ύc���openlist�ɕۑ�
		layOpenlist.value = aryOpenlist.join(",");
		
		var eSrc = document.getElementById(eSrc_id);
		if("object" == typeof(eSrc))
		{
			var eImg = eSrc.parentElement.children[0];
    		if(eImg) eImg.click();
		}
	}else{
		// ����TOC�����݂��Ȃ��ꍇ��opensie��SIE���}�[�L���Oand�I�[�v��
		Toc_MarkActiveAndLocation();
	}
}

function Toc_MarkActiveAndLocation()
{
	// opensie�̒l�Ɋ�Â�SIE���}�[�L���Oand�I�[�v������֐�
	var layOpensie = document.getElementById("opensie");
	if(layOpensie.value != "" && "object" == typeof(layOpensie))
	{
		// SIE���}�[�L���Oand�I�[�v��
		var obj = document.getElementById(layOpensie.value);
		if("object" == typeof(obj))
		{
			
			if(obj.target == "main")
		    {
			 	obj.className = "clsCurrentLI";
				obj.style.fontWeight = "bold";
				eSynchedNode = obj.parentElement;
				eCurrentObj = obj.parentElement;
				parent.frames("param").document.frm1.siecd.value = layOpensie.value;
				// �\������SIE�ƃA�N�e�B�u�ɂ���SIE���Ⴄ�ꍇ������B
				var AryUrl = obj.href.split('/');
				var thisdoc = AryUrl[AryUrl.length-1];
				var thissiecd = thisdoc.substring(0,thisdoc.lastIndexOf("."));
				top.main.location.href= obj.href.replace(thissiecd,document.getElementById("opendispsie").value);
			}
		}
		// opensie����ɂ���
		
		layOpensie.value = "";

	}
}

function window_load()
{
    var objStyle = null;
    if("object" == typeof ( ulRoot ) && "object" == typeof( objStyle = document.styleSheets[0] ) && "object" == typeof( objStyle.addRule ) )
    {
        window.eSynchedNode = document.all["eSynchedNode"];
        objStyle.addRule( "UL.clsHidden" , "display:none" , 0 );
        objStyle.addRule( "UL.hdn" , "display:none" , 0 );
        ulRoot.onclick=Toc_click;
        ulRoot.ondblclick=Toc_dblclick;
        document.onmouseover = mouse_over;
        if( window.eSynchedNode )
        {
            MarkActive(window.eSynchedNode);
            window.eSynchedNode.all.tags( "B" )[0].outerHTML = eSynchedNode.all.tags("B")[0].innerHTML;
            window.scrollTo(0,window.eSynchedNode.offsetTop-(document.body.clientHeight/2));
        }
        else
        {
            MarkActive(document.all.tags( "LI" )[0]);
        }
		Toc_open();
    }
	
}

//window.onload = window_load;
function xpath_save(xpath)
{
	parent.frames("param").document.frm1.xpath.value = xpath;
}
function sie_save(sie_repeat)
{
	parent.frames("param").document.frm1.sie_repeat.value = sie_repeat;
}

function NoOp()
{
	return;
}

//LI���o��܂ŌJ��Ԃ�
function parentElementRepeatLI(eSrc)
{
	var tagName = eSrc.parentElement.tagName;
	if(tagName == "LI"){
		return eSrc;
	}else if(tagName != "HTML"){
		return parentElementRepeatLI(eSrc.parentElement);
	}
	return null;
}
