function InitSrvc()
{
	if(parent.frames('srvc_menu').document.frm1)
	{
		parent.frames('srvc_menu').document.frm1.srvckbn.options[0].selected = true;
		parent.frames("srvc_menu").document.frm1.imgsmp.src = "../images/none.png";
		parent.frames('main').location.href = '/esicont/esi_common/default.html';
		parent.frames('param').frm1.siecd.value = '';
		document.frm1.submit();
	}
}

function InitSrvcHide()
{
    parent.frames('left_menu').document.all.HideMe.style.display = 'none';
	if(parent.frames('srvc_menu').document.frm1)
	{
		parent.frames('srvc_menu').document.frm1.srvckbn.options[0].selected = true;
		parent.frames("srvc_menu").document.frm1.imgsmp.src = "../images/none.png";
		parent.frames('main').location.href = '/esicont/esi_common/default.html';
		parent.frames('param').frm1.siecd.value = '';
		document.frm1.submit();
	}
}

function InitKeyWord(keyword)
{
	if(parent.frames('srvc_menu').document.frm1)
	{
		parent.frames('srvc_menu').document.frm1.srvckbn.options[0].selected = true;
		parent.frames('main').location.href = '/esicont/esi_common/default.html';
		parent.frames('param').frm1.siecd.value = '';
		document.frm1.keyword.value = keyword;
		document.frm1.submit();
	}
}
